This folder contains three .zip files for installing InteractiveJPDwB. To use InteractiveJPDwB, simply download this MAA-NCS18 file and extract the appropriate file based on your operating system. 

On LINUX:   application.linux64.zip

On MacOSX:  application.macosx.zip

On WINDOWS: application.windows64.zip

In the extracted folder, run the following executible: InteractiveJPDwB. 
